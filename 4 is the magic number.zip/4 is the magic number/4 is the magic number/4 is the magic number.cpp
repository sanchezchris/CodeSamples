// 4 is the magic number.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h";
#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <cctype>
using namespace std;


int main()
{

	int counter = 0;

	string teen[20] =
	{ "", "one", "two", "three", "four", "five", "six", "siven", "eight",
	"nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifthteen",
	"sixteen", "seventeen", "eighteen", "nineteen" };

	string tens[10] = { "", "", "twenty", "thirty", "fourty", "fifty", "sixty", "seventy",
	"eighty", "ninety" };

	int number;

	cout << "Enter a number between 0 and 9999\n";
	cin >> number;

	while ((number > 9999) || (number < 0)) {

		cout << "Enter a number between 0 and 9999\n";
		cin >> number;
	}

	while (counter != 4) {


		if (number == 0) {
			cout << "zero is 4\n\n";
			cout << "4 is the magic number\n\n";
			return 0;
		}

		int remainder;

		int thousandsP = number / 1000;


		if (thousandsP > 0) {
			cout << teen[thousandsP] << " thousand ";
			counter = counter + teen[thousandsP].length() + 8;
		}

		remainder = number % 1000;


		int hundredsP = remainder / 100;


		if (hundredsP > 0) {
			cout << teen[hundredsP] << " hundred ";
			counter = counter + teen[hundredsP].length() + 7;
		}

		remainder = remainder % 100;

		if (remainder < 20) {


			cout << teen[remainder];
			counter = counter + teen[remainder].length();


		}
		else {

			int tensP = remainder / 10;

			cout << tens[tensP] << " ";

			counter = counter + tens[tensP].length();

			remainder = remainder % 10;

			cout << teen[remainder];

			counter = counter + teen[remainder].length();

		}

		cout << " is " << counter << endl << endl;


		if (counter != 4) {
			number = counter;
			counter = 0;
		}


	}



	cout << "4 is the magic number";

	cout << endl << endl;

	return 0;
}