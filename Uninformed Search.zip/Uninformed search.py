# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 13:04:51 2019

@author: Christopher Sanchez
"""

# The grid values must be separated by spaces, e.g.
# 1 1 1 1 1
# 1 0 0 0 1
# 1 0 0 0 1
# 1 1 1 1 1
# Returns a 2D list of 1s and 0s
def readGrid(filename):
    #print('In readGrid')
    grid = []
    with open(filename) as f:
        for l in f.readlines():
            grid.append([int(x) for x in l.split()])
   
    f.close()
    #print 'Exiting readGrid'
    return grid
 
 
# Writes a 2D list of 1s and 0s with spaces in between each character
# 1 1 1 1 1
# 1 0 0 0 1
# 1 0 0 0 1
# 1 1 1 1 1
def outputGrid(grid, start, goal, path):
    #print('In outputGrid')
    filenameStr = 'path.txt'
 
    # Open filename
    f = open(filenameStr, 'w')
 
    # Mark the start and goal points
    grid[start[0]][start[1]] = 'S'
    grid[goal[0]][goal[1]] = 'G'
 
    # Mark intermediate points with *
    for i, p in enumerate(path):
        if i > 0 and i < len(path)-1:
            grid[p[0]][p[1]] = '*'
 
    # Write the grid to a file
    for r, row in enumerate(grid):
        for c, col in enumerate(row):
           
            # Don't add a ' ' at the end of a line
            if c < len(row)-1:
                f.write(str(col)+' ')
            else:
                f.write(str(col))
 
        # Don't add a '\n' after the last line
        if r < len(grid)-1:
            f.write("\n")
 
    # Close file
    f.close()
    #print('Exiting outputGrid')


# returns list of neighbors who's value == 0
def getNeighbors(location, grid):
    neighbors = []
    
    # Down
    if grid[location[0] + 1][location[1]] == 0:
        neighbors.append([location[0] + 1, location[1]])
    
    # Right
    if grid[location[0]][location[1] + 1] == 0:
        neighbors.append([location[0], location[1] + 1])
    
    # Up
    if grid[location[0] - 1][location[1]] == 0:
        neighbors.append([location[0] - 1, location[1]])
       
    # left
    if grid[location[0]][location[1] - 1] == 0:
        neighbors.append([location[0], location[1] - 1])
    return neighbors



# returns a updated list openList
# checks all children in children[]
# If a child isn't in the openList or closedList, 
    # a node is made for it and it is added to the updated openList
def expandNode(current, OL, CL, pChildren):
    updatedOL = OL
    
    for n in pChildren:
        test1 = True
        test2 = True
        for i in OL:
            if n == i.location:
                test1 = False
        for h in CL:
            if n == h.location:
                test2 = False
                
        if test1 and test2:
            updatedOL.append(Node(n, current))
    
    return updatedOL
    


# finds the path and returns it as a list
def setPath(current, path):
    
    while current.parent != None:
        path.append(current.location)
        current = current.parent
    
    path.append(current.location)
    return path


# finds the goal from the start location and writes a txt file
# to show it's path
def uninformedSearch(grid, start, goal, answer):
    
    current = Node(start, None)
    goalNode = Node(goal, None)
    openList = [current]
    closedList = []
    children = []
    path = []
    
    # search main loop
    while current.location != goalNode.location:
        if not openList:
            return False;
        
        # sets current to a element in OL and removes that ele from OL
        if (int(answer)) == 1:
            current = openList.pop(0)                   # BFS
        else:
            current = openList.pop(len(openList) - 1)   # DFS
        print("Current: ", current.location)
        
        # if found goalNode location, return true
        if current.location == goalNode.location:
            path = setPath(current, path)           # gets the path
            outputGrid(grid, start, goal, path)     # writes txt file
            return True
        # else add current to closedList
        else:
            closedList.append(current)
        
        # get neighbors and add them to children[]
        children = getNeighbors(current.location, grid)
        # for each child:
            #if the child isn't in OL or CL, create a node for it and add it to OL
        openList = expandNode(current, openList, closedList, children)
        
        # resets children[]
        children.clear()
        

# Node contains a location list ([y, x]) and pointer to its previous position
class Node:
    
    def __init__(self, value1, parent1):
        self.location = value1
        self.parent = parent1



def main():
    
    print("Enter 1 if you would like to run a Breadth First Search")
    print("Enter 2 if you would like to run a Depth First Search")
    answer = input("Answer: ")
    
    if (int(answer)) == 1:
        print("Breadth First Search")
    else:
        print("Depth First Search")
    
    print("Look for path.txt within your file system to see the path taken")
    
    # gets a 2D grid from Grid.txt
    #it must be in the same folder as this program
    myGrid = readGrid("Grid.txt"); # [y,x]
    
    # get the start and end values
    start = [1, 1];
    goal = [5, 6];
    
    # calls the search function
    result = uninformedSearch(myGrid, start, goal, answer)
    print(result)


main();





