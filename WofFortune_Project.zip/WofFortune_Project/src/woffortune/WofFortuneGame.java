/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// Christopher Sanchez
// Assignment 2
// ITIS 1213

package woffortune;

import static java.lang.Character.toUpperCase;
import java.util.ArrayList;
import java.util.*;

/**
 * WofFortuneGame class
 * Contains all logistics to run the game
 * @author clatulip
 */
public class WofFortuneGame {

    private boolean puzzleSolved = false;
    private int playerNumber = 0;
    
    private Wheel wheel;
    //private Player player1;
    private String phrase = "Once upon a time";
    private ArrayList<Letter> phraseArrayLetters = new ArrayList<Letter>();
    private ArrayList<String> randomPhraseArray = new ArrayList<String>();
    private ArrayList<Player> playerArray = new ArrayList<Player>();
    private String prizeArray[] = new String[10];
    
    /**
     * Constructor
     * @param wheel Wheel 
     * @throws InterruptedException 
     */
    public WofFortuneGame(Wheel wheel) throws InterruptedException {
        // get the wheel
        this.wheel = wheel;
        
        // do all the initialization for the game
        setUpGame();
        

    }
    
    /**
     * Plays the game
     * @throws InterruptedException 
     */
    public void playGame() throws InterruptedException {
        int n = 0;
        // while the puzzle isn't solved, keep going
        while (!puzzleSolved){
            // let the current player play
            playTurn(playerArray.get(n));
            n++;
            if(n == playerNumber){
                n = 0;
            }
        }
    }
    
    /**
     * Sets up all necessary information to run the game
     */
    private void setUpGame() {
        randomPhrases();
        
        // create a single player 
        //player1 = new Player("Player1");
        int random;
        int numOfPeople = 0;
        char answer;
        String playerName = null;
        Scanner input = new Scanner(System.in);
        
        // print out the rules
        System.out.println("RULES!");
        System.out.println("Each player gets to spin the wheel, to get a number value");
        System.out.println("Each player then gets to guess a letter. If the player has more than $150, they  ");
        System.out.println("can spend $150 to buy the right to guess a vowel. If that letter is in the phrase, ");
        System.out.println("the player will get the amount from the wheel for each occurence of the letter");
        System.out.println("If you have found a letter, you will also get a chance to guess at the phrase");
        System.out.println("Each player only has three guesses, once you have used up your three guesses, ");
        System.out.println("you can still guess letters, but no longer solve the puzzle.");
        System.out.println();
        
        fillingPrizeArray();
        
        // setting up number of players
        while(numOfPeople <= 0){
            System.out.println("How many people are going to play?");
            
            try{
                numOfPeople = input.nextInt();
            }
            catch(InputMismatchException e){
                System.out.println("You must only type integers. Ending Program");
                System.exit(0);   
            }
            catch(Throwable thrwobj){
                System.out.println("Error detected in CatchInput(). Quiting program.");
                System.exit(0);
            }
            playerNumber = numOfPeople;
        }
        
        for(int n = 0; n < numOfPeople; n++){
            System.out.print("Enter player " + (n+ 1) + "'s name: ");
            playerName = stringInput(false);      
            
            Player newPlayer = new Player(playerName);
            playerArray.add(newPlayer);
        }
        
        // allows user to set the phrase or picks one at random
        System.out.println("Do you want to enter a phrase? (if so type yes)");
        
        answer = stringInput(false).charAt(0);
        if ((answer == 'y') || (answer == 'Y')) {
            System.out.println("Enter your Phrase");
            phrase = stringInput(true);
        }
        else{
            random = (int)(Math.random() * 11);
            phrase = randomPhraseArray.get(random);
        }
        
        
        // for each character in the phrase, create a letter and add to letters array
        for (int i = 0; i < phrase.length(); i++) {
            phraseArrayLetters.add(new Letter(phrase.charAt(i)));
        }
        // setup done
    }
    
    /**
     * One player's turn in the game
     * Spin wheel, pick a letter, choose to solve puzzle if letter found
     * @param player
     * @throws InterruptedException 
     */
    private void playTurn(Player player){
        try{
            
            int money = 0;
            int randomPrize = 0;
            Scanner sc = new Scanner(System.in);
            boolean landedOnPrize = false;
            boolean buyingVowel = false;
            
            System.out.println(player.getName() + ", you have $" + player.getWinnings());
            System.out.println("Spin the wheel! <press enter>");
            stringInput(true);
            System.out.println("<SPINNING>");
            Thread.sleep(500);
            Wheel.WedgeType type = wheel.spin();
            System.out.print("The wheel landed on: ");
            
            
            
            switch (type) {
                case MONEY:
                    money = wheel.getAmount();
                    System.out.println("$" + money);
                    break;
                    
                case LOSE_TURN:
                    System.out.println("LOSE A TURN");
                    System.out.println("So sorry, you lose a turn.\n");
                    return; // doesn't get to guess letter
                    
                case PRIZE:
                    System.out.println("WIN A PRIZE");
                    System.out.println("Guess a correct letter to earn a prize\n");
                    landedOnPrize = true;
                    break;
                    
                case BANKRUPT:
                    System.out.println("BANKRUPT\n");
                    player.bankrupt();
                    return; // doesn't get to guess letter
                    
                default:
                    
            }
            System.out.println("");
            System.out.println("Here is the puzzle:");
            showPuzzle();
            System.out.println();

            if(player.getWinnings() >= 150){
                System.out.println("Would you like to buy a vowel for 150?");
                char ans = sc.next().charAt(0);
                if ((ans == 'y') || (ans == 'Y')) {
                    player.subtractWinnings(150);
                    buyingVowel = true;
                }
            }
            else{
                System.out.println("You do not have the funds to buy a vowel.");
            }
            
            System.out.println(player.getName() + ", please guess a letter.");
            
            char letter = stringInput(false).charAt(0);
            
            
            
            
            if (!Character.isAlphabetic(letter)) {
                System.out.println("Sorry, but only alphabetic characters are allowed. You lose your turn.\n");
            }
            else if((!buyingVowel) && (isVowel(letter))){
                System.out.println("You did not buy a vowel. You lose your turn.\n");
            }
            else {
                // search for letter to see if it is in
                int numFound = 0;
                for (Letter l : phraseArrayLetters) {
                    if ((l.getLetter() == letter) || (l.getLetter() == Character.toUpperCase(letter))) {
                        l.setFound();
                        numFound += 1;
                    }
                }
                if (numFound == 0) {
                    System.out.println("Sorry, but there are no " + letter + "'s.\n");
                } else {
                    if (numFound == 1) {
                        System.out.println("Congrats! There is 1 letter " + letter + ":");
                    } else {
                        System.out.println("Congrats! There are " + numFound + " letter " + letter + "'s:");
                    }
                    System.out.println();
                    showPuzzle();
                    System.out.println();
                    player.incrementScore(numFound*money);
                    System.out.println("You earned $" + (numFound*money) + ", and you now have: $" + player.getWinnings());
                    
                    // controls how a player gains a prize
                    if(landedOnPrize){
                        randomPrize = (int)(Math.random() * 10);
                        player.setPrizes(prizeArray[randomPrize]);
                        System.out.println("You have won " + prizeArray[randomPrize] + "!\n");
                        landedOnPrize = false;
                    }
                    
                    
                    System.out.println("Would you like to try to solve the puzzle? (Y/N)");
                    letter = stringInput(false).charAt(0);
                    System.out.println();
                    if ((letter == 'Y') || (letter == 'y')) {
                        solvePuzzleAttempt(player);
                    }
                }
            }
        }
        catch(InterruptedException a){
            System.out.println("Error detected in playTurn(). Quiting program.");
            System.exit(0);
            
        }
    }
    
    /**
     * Logic for when user tries to solve the puzzle
     * @param player 
     */
    private void solvePuzzleAttempt(Player player) {
        Player winner = null;
        
        if (player.getNumGuesses() >= 3) {
            System.out.println("Sorry, but you have used up all your guesses.");
            return;
        }
        
        player.incrementNumGuesses();
        System.out.println("What is your solution?");
        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("\n");
        String guess = stringInput(true);
        if (guess.compareToIgnoreCase(phrase) == 0) {
            System.out.println("Congratulations! You guessed it!\n");
            puzzleSolved = true;
            
            // Round is over. Write message with final stats
            for(int n = 0; n < playerNumber; n++){
                System.out.println(playerArray.get(n).getName() + " has $" + playerArray.get(n).getWinnings());
                
                // prints out prizes
                if(playerArray.get(n).getNumOfPrizes() != 0){
                    
                    for(int i = 0; i < (playerArray.get(n).getNumOfPrizes()); i++){
                        System.out.println(playerArray.get(n).getName() + " has won " + playerArray.get(n).getPrizes(i));
                    }
                    
                }
                
                
            }
            
            winner = playerArray.get(0);
            for(int n = 0; n < playerArray.size(); n++){
                if(winner.getWinnings() < playerArray.get(n).getWinnings()){
                    winner = playerArray.get(n);
                }
            }
            System.out.println(winner.getName() + " wins with $" + winner.getWinnings() + "!");
            
        } else {
            System.out.println("Sorry, but that is not correct.");
        }
    }
    
    /**
     * Display the puzzle on the console
     */
    private void showPuzzle() {
        System.out.print("\t\t");
        for (Letter l : phraseArrayLetters) {
            if (l.isSpace()) {
                System.out.print("   ");
            } else {
                if (l.isFound()) {
                    System.out.print(Character.toUpperCase(l.getLetter()) + " ");
                } else {
                    System.out.print(" _ ");
                }
            }
        }
        System.out.println();
        
    }
    
    /**
     * For a new game reset player's number of guesses to 0
     */
    public void reset() {
        
        for(int n = 0; n < playerNumber; n++){
            playerArray.get(n).reset();
            playerArray.get(n).bankrupt();
        }
        
    }
    
    
    
    // fills randomPhraseArray
    public void randomPhrases(){
        
        randomPhraseArray.add("Once upon a time");
        randomPhraseArray.add("An Eye for an Eye");
        randomPhraseArray.add("For the Horde");
        randomPhraseArray.add("Half Life three confirmed");
        randomPhraseArray.add("Thumbs up lets do this");
        randomPhraseArray.add("One Ring to rule them all");
        randomPhraseArray.add("War never changes");
        randomPhraseArray.add("The cake is a lie");
        randomPhraseArray.add("Not enough minerals");
        randomPhraseArray.add("Dont make Lemonade");
        randomPhraseArray.add("You are not prepared");
    }
    
    public void fillingPrizeArray(){
        
        prizeArray[0] = "a platypus";
        prizeArray[1] = "the Battlestar Galactica";
        prizeArray[2] = "a lifetime supply of Cyanide";
        prizeArray[3] = "the wife of your darkest dreams";
        prizeArray[4] = "free Dial-Up";
        prizeArray[5] = "a trip to North Karea";
        prizeArray[6] = "Mjolnir";
        prizeArray[7] = "some Cake";
        prizeArray[8] = "a homicidal hedgehog";
        prizeArray[9] = "earth-shattering credit card debt";
    }
    
    public String stringInput(boolean x){
        
        Scanner input = new Scanner(System.in);
        String inputString = null;
        
        try{
            if(x){
                inputString = input.nextLine();
            }
            else{
                inputString = input.next();
            }
        }
        catch(Throwable thrwobj){
            System.out.println("Error detected in CatchInput(). Quiting program.");
            System.exit(0);
        }
        
        return inputString;
    }
    
    public boolean isVowel(char letter){
        char vowels[] = {'a', 'e', 'i', 'o','u', 'y'};
        
        for(int n = 0; n < vowels.length; n++){
            if((letter == vowels[n]) || (letter == toUpperCase(vowels[n]))){
               return true; 
            }
        }
        return false;
    }
    
  
}
